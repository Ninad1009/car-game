import pygame
import random

# ---------------- SETTINGS ----------------
WIDTH, HEIGHT = 500, 700
FPS = 60

WHITE = (255, 255, 255)
BLACK = (20, 20, 20)
RED = (220, 50, 50)
GREEN = (50, 200, 50)
GRAY = (120, 120, 120)

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Endless Car Game")
clock = pygame.time.Clock()
font = pygame.font.SysFont("Arial", 30)

# Road lanes
LANES = [150, 250, 350]

# ---------------- PLAYER CAR ----------------
class PlayerCar:
    def __init__(self):
        self.lane = 1
        self.x = LANES[self.lane]
        self.y = 600
        self.width = 40
        self.height = 70

    def move_left(self):
        if self.lane > 0:
            self.lane -= 1
            self.x = LANES[self.lane]

    def move_right(self):
        if self.lane < 2:
            self.lane += 1
            self.x = LANES[self.lane]

    def draw(self):
        pygame.draw.rect(screen, GREEN,
                         (self.x-20, self.y, self.width, self.height))


# ---------------- OBSTACLE CARS ----------------
class Obstacle:
    def __init__(self):
        self.lane = random.randint(0, 2)
        self.x = LANES[self.lane]
        self.y = -80
        self.speed = 7
        self.width = 40
        self.height = 70

    def move(self):
        self.y += self.speed

    def draw(self):
        pygame.draw.rect(screen, RED,
                         (self.x-20, self.y, self.width, self.height))


# ---------------- GAME OVER SCREEN ----------------
def game_over(score):
    while True:
        screen.fill(BLACK)

        t1 = font.render("GAME OVER", True, RED)
        t2 = font.render(f"Score: {score}", True, WHITE)
        t3 = font.render("Press R to Restart", True, WHITE)

        screen.blit(t1, (150, 250))
        screen.blit(t2, (170, 320))
        screen.blit(t3, (110, 390))

        pygame.display.update()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    main()
                    return


# ---------------- MAIN GAME ----------------
def main():
    car = PlayerCar()
    obstacles = []
    score = 0
    spawn_timer = 0
    running = True

    while running:
        clock.tick(FPS)
        screen.fill(GRAY)

        # road lines
        pygame.draw.line(screen, WHITE, (200,0), (200,HEIGHT), 5)
        pygame.draw.line(screen, WHITE, (300,0), (300,HEIGHT), 5)

        # -------- EVENTS (USER CONTROL) --------
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    car.move_left()
                if event.key == pygame.K_RIGHT:
                    car.move_right()

        # spawn obstacles
        spawn_timer += 1
        if spawn_timer > 40:
            obstacles.append(Obstacle())
            spawn_timer = 0

        # move obstacles
        for obs in obstacles:
            obs.move()

        # remove old obstacles
        obstacles = [o for o in obstacles if o.y < HEIGHT+100]

        # collision detection
        for obs in obstacles:
            if obs.lane == car.lane and abs(obs.y - car.y) < 60:
                game_over(score)
                return

        # draw
        car.draw()
        for obs in obstacles:
            obs.draw()

        # score
        score += 1
        txt = font.render(f"Score: {score}", True, BLACK)
        screen.blit(txt, (20, 20))

        pygame.display.update()

    pygame.quit()


if __name__ == "__main__":
    main()