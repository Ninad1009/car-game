import pygame
import random
import asyncio

WIDTH, HEIGHT = 500, 700
FPS = 60

WHITE = (255,255,255)
BLACK = (20,20,20)
RED = (220,50,50)
GREEN = (50,200,50)
GRAY = (120,120,120)

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Endless Car Game")
clock = pygame.time.Clock()
font = pygame.font.SysFont("Arial",30)

LANES = [150,250,350]


class PlayerCar:
    def __init__(self):
        self.lane = 1
        self.x = LANES[self.lane]
        self.y = 600

    def move_left(self):
        if self.lane > 0:
            self.lane -= 1
            self.x = LANES[self.lane]

    def move_right(self):
        if self.lane < 2:
            self.lane += 1
            self.x = LANES[self.lane]

    def draw(self):
        pygame.draw.rect(screen,GREEN,(self.x-20,self.y,40,70))


class Obstacle:
    def __init__(self):
        self.lane = random.randint(0,2)
        self.x = LANES[self.lane]
        self.y = -80
        self.speed = 7

    def move(self):
        self.y += self.speed

    def draw(self):
        pygame.draw.rect(screen,RED,(self.x-20,self.y,40,70))


async def main():

    car = PlayerCar()
    obstacles = []
    score = 0
    spawn_timer = 0
    game_over = False

    while True:

        clock.tick(FPS)
        screen.fill(GRAY)

        pygame.draw.line(screen,WHITE,(200,0),(200,HEIGHT),5)
        pygame.draw.line(screen,WHITE,(300,0),(300,HEIGHT),5)

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                return

            if event.type == pygame.KEYDOWN:

                if not game_over:
                    if event.key == pygame.K_LEFT:
                        car.move_left()

                    if event.key == pygame.K_RIGHT:
                        car.move_right()

                else:
                    if event.key == pygame.K_r:
                        car = PlayerCar()
                        obstacles = []
                        score = 0
                        spawn_timer = 0
                        game_over = False

        if not game_over:

            spawn_timer += 1
            if spawn_timer > 40:
                obstacles.append(Obstacle())
                spawn_timer = 0

            for obs in obstacles:
                obs.move()

            obstacles = [o for o in obstacles if o.y < HEIGHT+100]

            for obs in obstacles:
                if obs.lane == car.lane and abs(obs.y-car.y) < 60:
                    game_over = True

            score += 1

        else:

            text1 = font.render("GAME OVER",True,RED)
            text2 = font.render("Press R to Restart",True,WHITE)

            screen.blit(text1,(160,300))
            screen.blit(text2,(120,350))

        car.draw()

        for obs in obstacles:
            obs.draw()

        text = font.render(f"Score: {score}",True,BLACK)
        screen.blit(text,(20,20))

        pygame.display.update()

        await asyncio.sleep(0)


asyncio.run(main())